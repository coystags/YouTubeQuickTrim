(function () {
  const ext = typeof browser !== "undefined" ? browser : chrome;
  function makeId() {
  return crypto.randomUUID();
}

  let initialized = false;
  let keyHandler = null;
  let timeUpdater = null;

  // ---------- STORAGE ----------
  function getHistory() {
  return new Promise(resolve => {
    ext.storage.local.get("ytClipHistory", async res => {
      let h = res.ytClipHistory || [];

      let changed = false;

      h = h.map(c => {
        if (!c.id) {
          changed = true;
          return { ...c, id: makeId() };
        }
        return c;
      });

      if (changed) {
        await ext.storage.local.set({ ytClipHistory: h });
      }

      resolve(h);
        });
      });
    }

  function setHistory(arr) {
    return new Promise(resolve => {
      ext.storage.local.set({ ytClipHistory: arr }, resolve);
    });
  }

  async function saveHistory(item) {
    const h = await getHistory();

    if (h.some(x =>
      x.videoId === item.videoId &&
      x.start === item.start &&
      x.end === item.end
    )) return;

    item.id = makeId();        // 
    item.created = Date.now();

    h.unshift(item);
    await setHistory(h.slice(0, 100));
  }

  // ---------- DESTROY UI ----------
  function destroyUI() {
  const sidebar = document.getElementById("ytClipSidebar");
  const fab = document.getElementById("ytClipFab");

  if (sidebar) sidebar.remove();
  if (fab) fab.remove();

  // Remove keyboard listener
  if (keyHandler) {
    document.removeEventListener("keydown", keyHandler);
    keyHandler = null;
  }

  // Clear timer
  if (timeUpdater) {
    clearInterval(timeUpdater);
    timeUpdater = null;
  }

  initialized = false;
}

  // ---------- WAIT ----------
  function wait() {
    const v = document.querySelector("video");
    if (v) init(v);
    else setTimeout(wait, 1000);
  }

  function init(video) {
    if (initialized) return;
    initialized = true;

    const url = new URL(location.href);
    const videoId = url.searchParams.get("v");
    if (!videoId) return;

    let startTime = null;
    let renderVersion = 0;
    let loop = false;
    let newestFirst = true;
    let open = false;
    let editClip = null; // { clip, originalIndex }
    let editLoop = null;
    

    function setSidebarMode(mode) {
      // visual modes: "idle" | "create" | "edit"

      if (mode === "create") {
        sidebar.style.borderLeft = "3px solid #4caf50"; // green
      }

      if (mode === "edit") {
        sidebar.style.borderLeft = "3px solid #ff9800"; // orange
      }

      if (mode === "idle") {
        sidebar.style.borderLeft = "1px solid #303030";
      }
    }

    // ---------- SIDEBAR ----------
    const sidebar = document.createElement("div");
    sidebar.id = "ytClipSidebar";

    Object.assign(sidebar.style, {
      position: "fixed",
      top: "0",
      right: "0",
      width: "300px",
      height: "100vh",
      background: "#0f0f0f",
      borderLeft: "1px solid #303030",
      zIndex: "999999",
      display: "flex",
      flexDirection: "column",
      transform: "translateX(100%)",
      transition: "transform 0.25s",
      color: "#fff",
      fontFamily: "Arial"
    });

    const status = document.createElement("div");
    status.textContent = "Idle";
    status.style.padding = "8px";

    const now = document.createElement("div");
    now.style.padding = "0 8px 8px 8px";

    function button(text) {
      const b = document.createElement("div");
      b.textContent = text;

      Object.assign(b.style, {
        margin: "0",
        width: "100%",
        boxSizing: "border-box",
        padding: "8px",
        background: "#272727",
        borderRadius: "8px",
        cursor: "pointer",
        textAlign: "center"
      });

      b.onmouseenter = () => b.style.background = "#3f3f3f";
      b.onmouseleave = () => b.style.background = "#272727";

      return b;
    }

    const startBtn = button("Start (S)");
    const loopBtn = button("Loop (L): OFF");
    const exportModeBtn = button("Export: comma");
    const exportBtn = button("Export");

    let exportMode = "comma"; // "comma" | "labels" | "independent"
    let clipStart = null; // Track if we're setting start or end

    const exportLabelBtn = button("Export + Labels");
    const orderBtn = button("Newest First");
    const independentExportBtn = button("Independent Export");
    const secondaryActions = document.createElement("div");

    Object.assign(secondaryActions.style, {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      padding: "8px"
    });

    secondaryActions.append(
      orderBtn
    );

    const topGrid = document.createElement("div");

    Object.assign(topGrid.style, {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "6px",
      padding: "8px"
    });

    topGrid.append(
      startBtn,
      loopBtn,
      exportBtn,
      exportModeBtn
    );

    const panel = document.createElement("div");

    Object.assign(panel.style, {
      flex: "1",
      overflowY: "auto",
      margin: "8px",
      borderTop: "1px solid #303030",
      paddingTop: "8px"
    });

    async function ordered() {
      const h = await getHistory();
      // Deduplicate by videoId + start + end (not URL, since URL changes on edit)
      const seen = new Set();
      const deduped = [];
      for (const clip of h) {
        const key = `${clip.videoId}|${clip.start}|${clip.end}`;
        if (!seen.has(key)) {
          seen.add(key);
          deduped.push(clip);
        }
      }
      const sorted = [...deduped].sort((a, b) => (b.created || 0) - (a.created || 0));
      return newestFirst ? sorted : sorted.reverse();
    }

    async function exportIndependent() {
  const h = await ordered();

  if (!h.length) {
    status.textContent = "No clips to export";
    return;
  }

  const text = h
    .map(c => {
      const label = (c.label && c.label.trim())
        ? c.label
        : `${c.title} (${c.start}-${c.end})`;
      return `${label} | v=${c.videoId}&start=${c.start}&end=${c.end}`;
    })
    .join("\n");

    navigator.clipboard.writeText(text);
    status.textContent = "Independent export copied!";
  }

    async function render() {
      const myVersion = ++renderVersion;

      panel.innerHTML = "";

      const h = await ordered();

      // If a newer render started, abandon this one
      if (myVersion !== renderVersion) return;

      if (!h.length) {
        panel.textContent = "No clips yet";
        return;
      }

      h.forEach(c => {
        const row = document.createElement("div");

        Object.assign(row.style, {
          display: "flex",
          alignItems: "center",
          background: "#272727",
          marginBottom: "6px",
          padding: "4px",
          borderRadius: "6px"
        });

        const label = document.createElement("div");
        label.style.flex = "1";
        label.style.fontSize = "12px";
        label.style.cursor = "pointer";
        label.textContent = c.label || `${c.title} (${c.start}-${c.end})`;

        // COPY
        label.onclick = () => {
          navigator.clipboard.writeText(c.url);
          status.textContent = "Copied!";
        };

        // EDIT LABEL
        label.ondblclick = () => {
          const input = document.createElement("input");
          input.value = c.label || "";

          row.replaceChild(input, label);
          input.focus();

          async function save() {
            const h = await getHistory();
            const i = h.findIndex(x => x.id === c.id);

            if (i !== -1) {
              h[i].label = input.value.trim();
              await setHistory(h);
            }

            render();
          }

          input.onblur = save;
          input.onkeydown = e => {
            if (e.key === "Enter") save();
          };
        };

        // DELETE
        const del = document.createElement("div");
        del.textContent = "❌";
        del.style.cursor = "pointer";
        del.style.marginLeft = "6px";

        del.onclick = async () => {
          const h = await getHistory();
          const newH = h.filter(x => x.id !== c.id);
          await setHistory(newH);
          render();
        };

        // EDIT BUTTON
        const edit = document.createElement("div");
        edit.textContent = "✏️";
        edit.style.cursor = "pointer";
        edit.style.marginLeft = "6px";

        edit.onclick = () => enterEditMode(c);

        row.append(label, del, edit);
        panel.appendChild(row);
      });
    }

    function enterEditMode(c) {
      const currentVideoId = new URL(location.href).searchParams.get("v");

      if (c.videoId !== currentVideoId) {
        // Create a clickable modal instead of alert
        const modal = document.createElement("div");
        modal.id = "ytClipModal";

        Object.assign(modal.style, {
          position: "fixed",
          top: "0",
          left: "0",
          width: "100%",
          height: "100%",
          background: "rgba(0, 0, 0, 0.8)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: "9999999"
        });

        const box = document.createElement("div");
        Object.assign(box.style, {
          background: "#272727",
          padding: "20px",
          borderRadius: "8px",
          maxWidth: "400px",
          textAlign: "center",
          color: "#fff",
          fontFamily: "Arial"
        });

        const msg = document.createElement("div");
        msg.textContent = "This clip belongs to a different video.";
        msg.style.marginBottom = "16px";

        const link = document.createElement("a");
        link.href = "https://www.youtube.com/watch?v=" + c.videoId;
        link.textContent = "Click to open the video";
        link.style.color = "#f0f0f0";
        link.style.textDecoration = "underline";
        link.style.cursor = "pointer";
        link.style.display = "inline-block";
        link.style.marginTop = "16px";

        const close = document.createElement("div");
        close.textContent = "Cancel";
        close.style.marginTop = "16px";
        close.style.cursor = "pointer";
        close.style.color = "#888";
        close.onclick = () => modal.remove();

        box.append(msg, link, close);
        modal.appendChild(box);
        document.body.appendChild(modal);

        return;
      }
      // Work on a copy of the clip, not the original in history
      const clipCopy = { ...c };
      editClip = { clip: clipCopy, originalStart: c.start, originalEnd: c.end };
      
     status.textContent = "Editing clip";
     setSidebarMode("edit");

     video.currentTime = c.start;

      startLoopEdit();
      renderEditUI(clipCopy);
    }

    function startLoopEdit() {
      if (editLoop) clearInterval(editLoop);

       editLoop = setInterval(() => {
        if (!editClip) return;

       const { clip } = editClip;

      if (video.currentTime >= clip.end) {
        video.currentTime = clip.start;
      }
  }, 100);
}

    function renderEditUI(c) {
      panel.innerHTML = "";

      const title = document.createElement("div");
      title.textContent = "Editing Clip";
      title.style.padding = "8px";

      const startLabel = document.createElement("div");
      const endLabel = document.createElement("div");

      function updateLabels() {
        startLabel.textContent = "Start: " + c.start.toFixed(2);
        endLabel.textContent = "End: " + c.end.toFixed(2);
      }

      const setStart = button("Set Start (Now)");
      const setEnd = button("Set End (Now)");

      const startMinus = button("-0.5s Start");
      const startPlus = button("+0.5s Start");
      const endMinus = button("-0.5s End");
      const endPlus = button("+0.5s End");
      const adjustGrid = document.createElement("div");

      Object.assign(adjustGrid.style, {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: "6px",
        width: "100%"
      });

      adjustGrid.append(
        startMinus,
        startPlus,
        endMinus,
        endPlus
      );

      const save = button("Save Changes");
      const exit = button("Exit Edit");

      setStart.onclick = () => {
        c.start = video.currentTime;
        video.currentTime = c.start;
        updateLabels();
      };

      setEnd.onclick = () => {
        c.end = video.currentTime;
        updateLabels();
      };

      startMinus.onclick = () => {
        c.start = Math.max(0, c.start - 0.5);
        updateLabels();
      };

      startPlus.onclick = () => {
        c.start = Math.min(c.end - 0.1, c.start + 0.5);
        updateLabels();
      };

      endMinus.onclick = () => {
        c.end = Math.max(c.start + 0.1, c.end - 0.5);
        updateLabels();
      };

      endPlus.onclick = () => {
        c.end = c.end + 0.5;
        updateLabels();
      };

      save.onclick = async () => {
        const h = await getHistory();
        const { clip, originalStart, originalEnd } = editClip;

        // REMOVE old version
        const filtered = h.filter(x =>
          x.id !== clip.id
        );

        // ADD updated version as a fresh entry
        const updated = {
          ...clip,
          created: Date.now(),
          url: `https://www.youtubetrimmer.com/view/?v=${clip.videoId}&start=${Math.floor(clip.start)}&end=${Math.ceil(clip.end)}&loop=${loop ? 1 : 0}`
        };

        filtered.unshift(updated);

        await setHistory(filtered);

        exitEditMode();
        render();
      };

      exit.onclick = () => exitEditMode();

      updateLabels();

      const editContainer = document.createElement("div");

    Object.assign(editContainer.style, {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      padding: "8px"
    });

    editContainer.append(
      title,
      startLabel,
      endLabel,
      setStart,
      adjustGrid,   
      setEnd,       
      save,
      exit
    );

    panel.append(editContainer);
} // CLOSED renderEditUI 

function exitEditMode() {
      editClip = null;

      if (editLoop) {
        clearInterval(editLoop);
        editLoop = null;
      }

      setSidebarMode("idle");

      render();
    }


    // ---------- LOGIC ----------
    startBtn.onclick = async () => {
      if (editClip) {
        editClip.clip.start = Math.floor(video.currentTime);
        renderEditUI(editClip.clip);
        return;
      }

      if (clipStart === null) {
        // First click: set start
        clipStart = Math.floor(video.currentTime);
        startBtn.textContent = "End (E)";
        status.textContent = "Start: " + clipStart + " - Click for End";
        setSidebarMode("create");
      } else {
        // Second click: set end
        const endTime = Math.ceil(video.currentTime);
        if (endTime <= clipStart) return alert("End must be after start");

        const currentUrl = new URL(location.href);
        const currentVideoId = currentUrl.searchParams.get("v");
        const currentTitle = document.title.replace(" - YouTube", "");

        const clipUrl =
  `https://www.youtubetrimmer.com/view/?v=${currentVideoId}&start=${clipStart}&end=${endTime}&loop=${loop ? 1 : 0}`;

        await saveHistory({
          videoId: currentVideoId,
          title: currentTitle,
          start: clipStart,
          end: endTime,
          url: clipUrl
        });

        clipStart = null;
        startBtn.textContent = "Start (S)";
        render();
        setSidebarMode("idle");
      }
    };

    exportModeBtn.onclick = () => {
      if (exportMode === "comma") {
        exportMode = "labels";
        exportModeBtn.textContent = "Export: labels";
      } else if (exportMode === "labels") {
        exportMode = "independent";
        exportModeBtn.textContent = "Export: independent";
      } else {
        exportMode = "comma";
        exportModeBtn.textContent = "Export: comma";
      }
    };

    loopBtn.onclick = () => {
      loop = !loop;
      loopBtn.textContent = "Loop (L): " + (loop ? "ON" : "OFF");
    };

    exportBtn.onclick = async () => {
      const h = await ordered();
      let text;

      if (exportMode === "comma") {
        text = h.map(c => c.url).join(", ");
        status.textContent = "Exported (comma)!";
      } else if (exportMode === "labels") {
        text = h
          .map(c => `${c.label || c.title} - ${c.url}`)
          .join(", ");
        status.textContent = "Exported (labels)!";
      } else {
        // independent
        text = h
          .map(c => {
            const label = (c.label && c.label.trim())
              ? c.label
              : `${c.title} (${c.start}-${c.end})`;
            return `${label} | v=${c.videoId}&start=${c.start}&end=${c.end}`;
          })
          .join("\n");
        status.textContent = "Exported (independent)!";
      }

      navigator.clipboard.writeText(text);
    };

    exportLabelBtn.onclick = async () => {
      const h = await ordered();
      const text = h
        .map(c => `${c.label || c.title} - ${c.url}`)
        .join(", ");
      navigator.clipboard.writeText(text);
      status.textContent = "Exported with labels!";
    };

    independentExportBtn.onclick = exportIndependent;

    orderBtn.onclick = () => {
      newestFirst = !newestFirst;
      orderBtn.textContent = newestFirst ? "Newest First" : "Oldest First";
      render();
    };

    // ---------- SHORTCUTS ----------
keyHandler = (e) => {
  const active = document.activeElement;

  // Ignore typing fields
  if (
    active &&
    (
      active.tagName === "INPUT" ||
      active.tagName === "TEXTAREA" ||
      active.isContentEditable
    )
  ) return;

  const k = e.key.toLowerCase();

  // Allow toggle always
  if (k === "c") {
    document.getElementById("ytClipFab")?.click();
  }

  // Ignore when sidebar is closed (for other keys)
  if (!open) return;

  if (k === "s") startBtn.click();
  if (k === "l") loopBtn.click();
  if (k === "e") {
    // E key: if clipStart is set, act as end; otherwise do nothing
    if (clipStart !== null) startBtn.click();
  }
};

document.addEventListener("keydown", keyHandler);

    // ---------- FLOAT BUTTON ----------
    const fab = document.createElement("div");
    fab.id = "ytClipFab";
    fab.textContent = "CLIPS";

    Object.assign(fab.style, {
      position: "fixed",
      right: "12px",
      bottom: "20px",
      color: "#ff3b3b",
      fontWeight: "bold",
      background: "#0f0f0f",
      padding: "6px 10px",
      borderRadius: "8px",
      cursor: "pointer",
      border: "1px solid #303030",
      zIndex: "1000000"
    });

    fab.onclick = () => {
      open = !open;
      sidebar.style.transform = open ? "translateX(0)" : "translateX(100%)";
      if (open) render();
    };

    document.body.appendChild(fab);

    // ---------- TIME ----------
    timeUpdater = setInterval(() => {
  now.textContent = "Now: " + Math.floor(video.currentTime);
}, 500);

    // ---------- BUILD ----------
    sidebar.append(
      status,
      now,
      topGrid,
      secondaryActions, // 
      panel
);

    document.body.appendChild(sidebar);
  }

  // ---------- INITIAL LOAD ----------
  ext.storage.local.get("enabled", res => {
    if (res.enabled !== false) wait();
  });

  // ---------- LIVE TOGGLE ----------
  ext.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.enabled) return;

    if (changes.enabled.newValue) {
      wait();
    } else {
      destroyUI();
    }
  });

})();
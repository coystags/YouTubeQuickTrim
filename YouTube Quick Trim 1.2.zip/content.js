(function () {
  const ext = typeof browser !== "undefined" ? browser : chrome;

  let initialized = false;

  // ---------- STORAGE ----------
  function getHistory() {
    return new Promise(resolve => {
      ext.storage.local.get("ytClipHistory", res => {
        resolve(res.ytClipHistory || []);
      });
    });
  }

  function setHistory(arr) {
    return new Promise(resolve => {
      ext.storage.local.set({ ytClipHistory: arr }, resolve);
    });
  }

  async function saveHistory(item) {
    const h = await getHistory();
    h.unshift(item);
    await setHistory(h.slice(0, 100));
  }

  // ---------- DESTROY UI ----------
  function destroyUI() {
    const sidebar = document.getElementById("ytClipSidebar");
    const fab = document.getElementById("ytClipFab");

    if (sidebar) sidebar.remove();
    if (fab) fab.remove();

    initialized = false;
  }

  // ---------- WAIT ----------
  function wait() {
    const v = document.querySelector("video");
    if (v) init(v);
    else setTimeout(wait, 1000);
  }

  function init(video) {
    if (initialized) return;
    initialized = true;

    const url = new URL(location.href);
    const videoId = url.searchParams.get("v");
    if (!videoId) return;

    const videoTitle = document.title.replace(" - YouTube", "");

    let startTime = null;
    let loop = false;
    let newestFirst = true;
    let open = false;

    // ---------- SIDEBAR ----------
    const sidebar = document.createElement("div");
    sidebar.id = "ytClipSidebar";

    Object.assign(sidebar.style, {
      position: "fixed",
      top: "0",
      right: "0",
      width: "300px",
      height: "100vh",
      background: "#0f0f0f",
      borderLeft: "1px solid #303030",
      zIndex: "999999",
      display: "flex",
      flexDirection: "column",
      transform: "translateX(100%)",
      transition: "transform 0.25s",
      color: "#fff",
      fontFamily: "Arial"
    });

    const status = document.createElement("div");
    status.textContent = "Idle";
    status.style.padding = "8px";

    const now = document.createElement("div");
    now.style.padding = "0 8px 8px 8px";

    function button(text) {
      const b = document.createElement("div");
      b.textContent = text;

      Object.assign(b.style, {
        margin: "6px 8px",
        padding: "8px",
        background: "#272727",
        borderRadius: "8px",
        cursor: "pointer",
        textAlign: "center"
      });

      b.onmouseenter = () => b.style.background = "#3f3f3f";
      b.onmouseleave = () => b.style.background = "#272727";

      return b;
    }

    const startBtn = button("Start (S)");
    const endBtn = button("End (E)");
    const loopBtn = button("Loop (L): OFF");
    const exportBtn = button("Export");
    const exportLabelBtn = button("Export + Labels");
    const orderBtn = button("Newest First");
    const independentExportBtn = button("Independent Export");

    const panel = document.createElement("div");

    Object.assign(panel.style, {
      flex: "1",
      overflowY: "auto",
      margin: "8px",
      borderTop: "1px solid #303030",
      paddingTop: "8px"
    });

    async function ordered() {
      const h = await getHistory();
      return newestFirst ? h : [...h].reverse();
    }

    async function exportIndependent() {
  const h = await ordered();

  if (!h.length) {
    status.textContent = "No clips to export";
    return;
  }

  const text = h
    .map(c => {
      const label = (c.label && c.label.trim())
        ? c.label
        : `${c.title} (${c.start}-${c.end})`;
      return `${label} | v=${c.videoId}&start=${c.start}&end=${c.end}`;
    })
    .join("\n");

    navigator.clipboard.writeText(text);
    status.textContent = "Independent export copied!";
  }

    async function render() {
      panel.innerHTML = "";
      const h = await ordered();

      if (!h.length) {
        panel.textContent = "No clips yet";
        return;
      }

      h.forEach(c => {
        const row = document.createElement("div");

        Object.assign(row.style, {
          display: "flex",
          alignItems: "center",
          background: "#272727",
          marginBottom: "6px",
          padding: "4px",
          borderRadius: "6px"
        });

        const label = document.createElement("div");
        label.style.flex = "1";
        label.style.fontSize = "12px";
        label.style.cursor = "pointer";
        label.textContent = c.label || `${c.title} (${c.start}-${c.end})`;

        // EDIT LABEL
        label.ondblclick = () => {
          const input = document.createElement("input");
          input.value = c.label || "";

          row.replaceChild(input, label);
          input.focus();

          async function save() {
            const h = await getHistory();
            const i = h.findIndex(x => x.url === c.url);
            if (i !== -1) {
              h[i].label = input.value.trim();
              await setHistory(h);
            }
            render();
          }

          input.onblur = save;
          input.onkeydown = e => {
            if (e.key === "Enter") save();
          };
        };

        // COPY
        label.onclick = () => {
          navigator.clipboard.writeText(c.url);
          status.textContent = "Copied!";
        };

        // DELETE
        const del = document.createElement("div");
        del.textContent = "❌";
        del.style.cursor = "pointer";
        del.style.marginLeft = "6px";

        del.onclick = async () => {
          const h = await getHistory();
          const newH = h.filter(x => x.url !== c.url);
          await setHistory(newH);
          render();
        };

        row.append(label, del);
        panel.appendChild(row);
      });
    }

    // ---------- LOGIC ----------
    startBtn.onclick = () => {
      startTime = Math.floor(video.currentTime);
      status.textContent = "Start: " + startTime;
      sidebar.style.borderLeft = "3px solid #4caf50";
    };

    endBtn.onclick = async () => {
      if (startTime === null) return alert("Set start first");

      const endTime = Math.floor(video.currentTime);
      if (endTime <= startTime) return alert("Invalid end");

      const clipUrl =
        `https://www.youtubetrimmer.com/view/?v=${videoId}&start=${startTime}&end=${endTime}&loop=${loop ? 1 : 0}`;

      await saveHistory({
        videoId,
        title: videoTitle,
        start: startTime,
        end: endTime,
        url: clipUrl
      });

      navigator.clipboard.writeText(clipUrl);

      startTime = null;
      sidebar.style.borderLeft = "1px solid #303030";
      status.textContent = "Saved!";

      render();
    };

    loopBtn.onclick = () => {
      loop = !loop;
      loopBtn.textContent = "Loop (L): " + (loop ? "ON" : "OFF");
    };

    exportBtn.onclick = async () => {
      const h = await ordered();
      const text = h.map(c => c.url).join(", ");
      navigator.clipboard.writeText(text);
      status.textContent = "Exported!";
    };

    exportLabelBtn.onclick = async () => {
      const h = await ordered();
      const text = h
        .map(c => `${c.label || c.title} - ${c.url}`)
        .join(", ");
      navigator.clipboard.writeText(text);
      status.textContent = "Exported with labels!";
    };

    independentExportBtn.onclick = exportIndependent;

    orderBtn.onclick = () => {
      newestFirst = !newestFirst;
      orderBtn.textContent = newestFirst ? "Newest First" : "Oldest First";
      render();
    };

    // ---------- SHORTCUTS ----------
document.addEventListener("keydown", (e) => {
  const active = document.activeElement;

  // Ignore typing fields (robust check)
  if (
    active &&
    (
      active.tagName === "INPUT" ||
      active.tagName === "TEXTAREA" ||
      active.isContentEditable
    )
  ) return;

  // Ignore when sidebar is closed
  if (!open) return;

  const k = e.key.toLowerCase();

  if (k === "s") startBtn.click();
  if (k === "e") endBtn.click();
  if (k === "l") loopBtn.click();
  if (k === "c") fab.click();
});

    // ---------- FLOAT BUTTON ----------
    const fab = document.createElement("div");
    fab.id = "ytClipFab";
    fab.textContent = "CLIPS";

    Object.assign(fab.style, {
      position: "fixed",
      right: "12px",
      bottom: "20px",
      color: "#ff3b3b",
      fontWeight: "bold",
      background: "#0f0f0f",
      padding: "6px 10px",
      borderRadius: "8px",
      cursor: "pointer",
      border: "1px solid #303030",
      zIndex: "1000000"
    });

    fab.onclick = () => {
      open = !open;
      sidebar.style.transform = open ? "translateX(0)" : "translateX(100%)";
      if (open) render();
    };

    document.body.appendChild(fab);

    // ---------- TIME ----------
    setInterval(() => {
      now.textContent = "Now: " + Math.floor(video.currentTime);
    }, 500);

    // ---------- BUILD ----------
    sidebar.append(
      status,
      now,
      startBtn,
      endBtn,
      loopBtn,
      exportBtn,
      exportLabelBtn,
      independentExportBtn,
      orderBtn,
      panel
);

    document.body.appendChild(sidebar);
  }

  // ---------- INITIAL LOAD ----------
  ext.storage.local.get("enabled", res => {
    if (res.enabled !== false) wait();
  });

  // ---------- LIVE TOGGLE ----------
  ext.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.enabled) return;

    if (changes.enabled.newValue) {
      wait();
    } else {
      destroyUI();
    }
  });

})();
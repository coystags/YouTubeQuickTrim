const ext = typeof browser !== "undefined" ? browser : chrome;
const toggle = document.getElementById("toggle");

ext.storage.local.get("enabled").then(res => {
  toggle.checked = res.enabled !== false;
});

toggle.addEventListener("change", () => {
  ext.storage.local.set({ enabled: toggle.checked });
});

const viewerInput = document.getElementById("viewerUrl");
const openBtn = document.getElementById("openViewer");

// Load saved URL
ext.storage.local.get("viewerUrl").then(res => {
  if (res.viewerUrl) viewerInput.value = res.viewerUrl;
});

// Save URL when edited
viewerInput.addEventListener("input", () => {
  ext.storage.local.set({ viewerUrl: viewerInput.value });
});

// Open the viewer
openBtn.addEventListener("click", () => {
  let url = viewerInput.value.trim();

  if (!url) return;

  // add https:// if missing (prevents silent failure)
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    url = "https://" + url;
  }

  ext.tabs.create({ url });
});